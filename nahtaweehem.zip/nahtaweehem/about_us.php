<?php
include("config.php");
include("functions.php");

//title of the page
$ptitle = "من نحن";

//including header files
include("includes/header.php");
include("includes/sidebar.php");
?>

<section class="mbr-fullscreen">
    <div class="bg4 mbr-overlay">
        <br><br><br><br><br><br><br>
        <div class="text-center text-white">
            <span style="font-size:40pt" class="myshadow_d">نحتويهم</span>

            <br><br><br>
            <h3 class="text-white myshadow_d">
                هي منظمة غير ربحية . نحن مجموعة من الطالبات نهدف إلى دعم العائلات التي تكافح سرطان الأطفال ومحاولة إسعاد محاربيهم الصغار. يعاني العديد من العائلات التي لديها أطفال مرضى من ضائقة عاطفية وجسدية ومالية
                <br>
                نحاول إزالة قلق واحد على الأقل من أكتافهم ومنحهم شيئًا سحريًا
            </h3>
            <br><br><br>
            <?php
            if (USER_EMAIL == "") {
            ?>
            <a class="btn btn-lg btn-warning badge-pill" href="register.php">انضم معنا لتحتويهم <i class="fa fa-heart-o" aria-hidden="true"></i></a>
            <?php
            }
            ?>
        </div>
    </div>
    </div>
</section>

<?php
//including footer layout
include("includes/footer.php");
?>