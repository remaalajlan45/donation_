<?php
include("config.php");
include("functions.php");

//title of the page
$ptitle = "سجل معنا";

//including header files
include("includes/header.php");
include("includes/sidebar.php");
?>

<section class="mbr-fullscreen">
    <div class="bg5 mbr-overlay">
        <br><br><br><br><br><br><br>
        <div class="row text-center text-dark myshadow_w ">
            <div class="col-lg-6">
                <h2><strong>مرحبا بك ياصغيري</strong></h2>
                <br><br><br>
                <h3 class="text-white myshadow_d">هدفنا هي رؤية ابتسامتك البريئة</h3>
                <br>
                <a class="btn btn-lg btn-light badge-pill" href="patient_register.php">هيا انضم معنا</a>
            </div>
            <div class="col-lg-6">
                <h2><strong>مرحبا بك</strong></h2>
                <br><br>
                <h5 class="text-white myshadow_d">سنكون سعيدين جدا اذا انضميت الى عائلتنا وساعدتنا لنحتوي هؤلاء الاطفال ف بامكانك تقديم المساعدة المالية او تقديم الدروس لهم ومساعدتهم في اكمال تعليمهم فانضم معنا لنحتويهم</h5>
                <br>
                <a class="btn btn-lg btn-light badge-pill" href="supporter_register.php">سجل هنا كداعم</a>
            </div>
        </div>
    </div>
    </div>
</section>

<?php
//including footer layout
include("includes/footer.php");
?>