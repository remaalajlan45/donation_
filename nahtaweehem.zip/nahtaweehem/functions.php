<?php
// --- getting user data as object
function user($term)
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM user WHERE email ='$term' or id='$term'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}

// --- getting consultant data as object
function consultant($term, $get = "id")
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM consultant WHERE $get ='$term'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}

// --- getting patient data as object
function patient($term, $get = "id")
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM patient WHERE $get ='$term'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}
// --- getting supporter data as object
function supporter($term, $get = "id")
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM supporter WHERE $get ='$term'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}

// --- getting hospital data as object
function hospital($id)
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM hospital WHERE id ='$id'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}

// --- getting support data as object
function support($id)
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM support WHERE id ='$id'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}

// --- getting support_consultation data as object
function support_consultation($id)
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM support_consultation WHERE id ='$id'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}

// --- getting support_donation data as object
function support_donation($id)
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM support_donation WHERE id ='$id'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}

// --- getting support_education data as object
function support_education($id)
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM support_education WHERE id ='$id'");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return mysqli_fetch_object($res);
	} else {
		return false;
	}
}

//function to check user account exist in database or not
function user_exist($id, $email, $phone)
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM user WHERE id <> '$id' AND (lcase(email)=lcase('$email') or phone='$phone')");
	$numrows = mysqli_num_rows($res);
	if ($numrows > 0) {
		return true;
	} else {
		return false;
	}
}

//function to get list in <select>
function hospital_list($id, $required = "required")
{
	global $link;
?>
	<select class="form-control" id="hospital_id" name="hospital_id" <?php echo $required ?>>
		<option value="" hidden>قم بالاختيار</option>
		<?php
		// retriving data from database
		$sql = "SELECT * FROM hospital ORDER by id ASC";
		$res = mysqli_query($link, $sql);
		$numrows = mysqli_num_rows($res);
		if ($numrows > 0) {
			while ($obj = mysqli_fetch_object($res)) {
		?>
				<option value="<?php echo $obj->id; ?>" <?php if ($id == $obj->id) {
															echo 'selected';
														} ?>>
					<?php echo $obj->name; ?>
				</option>
			<?php
			}
		} else {
			?>
			<option value="0">لا توجد بيانات</option>
		<?php
		} ?>
	</select>
<?php
}


function support_type_list($id, $required = "required")
{
?>
	<select class="form-control" name="support_type" <?php echo $required ?>>
		<option value="" hidden>قم بالاختيار</option>
		<option value="consultation" <?php if ($id == "consultation") {
											echo 'selected';
										} ?>>طلب دعم استشاري</option>
		<option value="education" <?php if ($id == "education") {
										echo 'selected';
									} ?>>طلب دعم تعليمي</option>
		<option value="donation" <?php if ($id == "donation") {
										echo 'selected';
									} ?>>طلب دعم مادي</option>
	</select>
<?php
}


//--- function to print message box with message ---
function msg($msg, $type)
{
?>
	<div class="alert alert-<?php echo $type; ?> alert-dismissable">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<?php echo $msg; ?>
	</div>
<?php
}

//---- function to get the total number of rows in table---
function numrows($table, $condition = "")
{
	global $link;
	$res = mysqli_query($link, "SELECT * FROM $table $condition");
	return mysqli_num_rows($res);
}

//Function to upload a file from client to server
function upload_file($target_dir, $file, $type, &$err, &$errmsg)
{
	$ret = null;
	if (is_uploaded_file($file['tmp_name'])) {
		//Setting name
		$alphanum = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$imgid = "";
		for ($i = 1; $i <= 10; $i++) {
			$pos  = intval(floor(rand(0, (strlen($alphanum) - 1))));
			$imgid = $imgid . "" . $alphanum{
				$pos};
		}
		$imgname = $imgid;

		//gettig properties
		$target_file1 = $target_dir . basename($file['name']);

		//getting type
		$FileType = strtolower(pathinfo($target_file1, PATHINFO_EXTENSION));

		$target_file = $target_dir . $imgname . "." . $FileType;

		//getting size of image and check it
		$check = @getimagesize($file['tmp_name']);

		if ($type == "image" && $check === false) {
			$err = "y";
			$errmsg = "هناك خطأ في ملف الصورة";
		} elseif ($type == "image" && $FileType != "jpg" && $FileType != "png" && $FileType != "jpeg") {
			$err = "y";
			$errmsg = "عذراً فقط يمكنك تحميل صور من النوع JPG, JPEG & PNG";
		} elseif ($type == "pdf" && $FileType != "pdf") {
			$err = "y";
			$errmsg = "عذراً فقط يمكنك تحميل ملفات بامتداد PDF فقط";
		} elseif ($file['size'] > 2000000) {
			//checking the size
			$err = "y";
			$errmsg = "حجم الصورة او الملف يجب الا يتجاوز 2 ميجا";
		} else {
			if (move_uploaded_file($file['tmp_name'], $target_file)) {
				$upload = "y";
				$ret = $target_dir . $imgname . "." . $FileType;
			} else {
				$err = "y";
				$errmsg = "حدثت مشكلة أثناء رفع الصورة";
			}
		}
		return $ret;
	}
}

function model_patient($obj)
{
	$obj2 = user($obj->user_id);
?>
	<!-- Modal -->
	<div id="model_patient<?php echo $obj->id; ?>" class="modal fade" role="dialog">
		<div class="modal-dialog">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<center>
						<h4 class="modal-title">
							<?php echo $obj2->name; ?>
							<br>
							<small><?php echo user_type_lang($obj2->type); ?></small>
						</h4>
					</center>
				</div>
				<div class="modal-body">
					<center>
						<b>البريد الالكتروني:</b> <?php echo $obj2->email; ?>
						<br>
						<b>تاريخ الميلاد:</b> <?php echo $obj2->dob; ?>
						<br>
						<b>الجوال:</b> <?php echo $obj2->phone; ?>
						<br>
						<b>العنوان:</b> <?php echo $obj2->address; ?>
						<br>

						<b>المستشفى:</b> <?php echo hospital($obj->hospital_id)->name; ?>
						<br>
						<b>نوع المرض:</b> <?php echo $obj->cancer_type; ?>
						<br>
						<b>وصف:</b> <?php echo $obj->bio; ?>
						<br>
						<b>الاحتياجات:</b> <?php echo $obj->needs; ?>

					</center>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-secondary" data-dismiss="modal">اغلاق</button>
				</div>
			</div>

		</div>
	</div>
<?php
}

function user_type_lang($term)
{
	if ($term == "consultant") {
		return "حساب استشاري";
	} elseif ($term == "patient") {
		return "حساب طفل";
	} elseif ($term == "supporter") {
		return "حساب داعم";
	}
}

function support_type_lang($term)
{
	if ($term == "education") {
		return "طلب دعم تعليمي";
	} elseif ($term == "donation") {
		return "طلب دعم مادي";
	} elseif ($term == "consultation") {
		return "طلب دعم استشاري";
	}
}

if (USER_EMAIL != "") {
	$u = user(USER_EMAIL);
	$user_id = $u->id;
	if ($u->type == "consultant") {
		$c = consultant($u->id, "user_id");
		$c_id = $c->id;
	} else if ($u->type == "patient") {
		$p = patient($u->id, "user_id");
		$p_id = $p->id;
	} else if ($u->type == "supporter") {
		$s = supporter($u->id, "user_id");
		$s_id = $s->id;
	}
}
?>