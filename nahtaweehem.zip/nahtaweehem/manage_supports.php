<?php
include("config.php");
include("functions.php");

//---- check user login and type
if (USER_EMAIL == "" || $u->type == "patient") {
    header("location:user_login.php");
    exit();
}


$ptitle = "إدارة طلباتي";
//--- include sub files ------
include("includes/header.php");
include("includes/sidebar.php");
?>

<!-- =============================== End of Action Part =============================== -->
<!-- =============================== Design Part =============================== -->
<div class="main">
    <div>
        <?php
        //-- printing message if there is any message ---
        if ($err == "y") {
            msg($errmsg, "danger");
        }

        if ($succ == "y") {
            msg($smsg, "success");
        }
        ?>
    </div>

    <?php
    include("includes/include_supports.php");
    ?>

</div>


<?php
include("includes/footer.php");
?>