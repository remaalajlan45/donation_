<?php
include("config.php");
include("functions.php");

//---- if login is not done then it will redirect to login page
if (USER_EMAIL == "") {
    header("location:user_login.php");
    exit();
} else {
    $obj = user(USER_EMAIL);
    $id = $obj->id;
}

/* =============================== Action Part =============================== */
// ------ update password -----------
if (isset($_POST["opass"]) && isset($_POST["npass"]) && isset($_POST["vpass"])) {

    //--- getting form data ----
    $opass = $_POST["opass"];
    $npass = $_POST["npass"];
    $vpass = $_POST["vpass"];

    //-- validation of submitted data ---
    if ($obj->password != $opass) {
        $err = "y";
        $errmsg = "كلمة المرور القديمة ليست صحيحة";
    }

    if ($err == "n" && strlen($_POST["npass"]) < 8) {
        $err = "y";
        $errmsg = "كلمة المرور يجب أن تكون 8 احرف على الأقل";
    }

    if ($err == "n" && $npass != $vpass) {
        $err = "y";
        $errmsg = "كلمة المرور الجديدة والتأكيدية غير متطابقتين";
    }

    //--- if validation is OKAY -----
    if ($err == "n") {
        $sql = "UPDATE user SET
      password = '$npass'
      WHERE id = '$id'";

        $res = mysqli_query($link, $sql);
        echo mysqli_error($link);

        if ($res) {
            $succ = "y";
            $smsg = "تم تغيير كلمة المرور بنجاح";
        }
    }
}

$ptitle = SITENAME . " - تغيير كلمة المرور";
//--- include sub files ------
include("includes/header.php");
include("includes/sidebar.php");
?>
<!-- =============================== End of Action Part =============================== -->



<!-- =============================== Design Part =============================== -->
<div class="main">
    <div>
        <?php
        //-- printing message if there is any message ---
        if ($err == "y") {
            msg($errmsg, "danger");
        }

        if ($succ == "y") {
            msg($smsg, "success");
        }
        ?>
    </div>

    <form method="post">

        <div class="form-group">
            <label>كلمة المرور القديمة:<span class="mandatory">*</span></label>
            <input type="password" class="form-control" name="opass" required="" placeholder="ادخل كلمة المرور السابقة هنا">
        </div>

        <div class="form-group">
            <label>كلمة المرور الجديدة:<span class="mandatory">*</span></label>
            <input type="password" class="form-control" name="npass" required="" placeholder="ادخل كلمة المرور الجديدة هنا">
        </div>

        <div class="form-group">
            <label>كلمة المرور التأكيدية:<span class="mandatory">*</span></label>
            <input type="password" class="form-control" name="vpass" required="" placeholder="اعد ادخال كلمة المرور الجديدة هنا">
        </div>

        <button type="submit" class="btn btn-primary">تغيير كلمة المرور</button>
        <button type="reset" class="btn btn-outline-secondary">تصفية الحقول</button>
    </form>
    <!-- =============================== End of Design Part =============================== -->
</div>

<?php
include("includes/footer.php");
?>