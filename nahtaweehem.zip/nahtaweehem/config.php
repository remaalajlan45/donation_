<?php
@session_start();

//Setting Time to local time zone
date_default_timezone_set('Asia/Riyadh');

//Connecting with database
define("SITENAME","نحتويهم");
define("HOST","localhost");
define("DBUSER","root");
define("DBPASS","");
define("DB","nahtaweehem");

$link = mysqli_connect(HOST, DBUSER, DBPASS, DB) or die("خطأ اثناء الاتصال مع قاعدة البيانات");

//Arabic support codes
mysqli_query($link, "SET NAMES 'utf8'") or die('Can\'t charset in DataBase');
mysqli_query($link, "SET CHARACTER SET utf8") or die('Can\'t charset in DataBase');

//-- checking user login ---
if(isset($_SESSION["USER_EMAIL"])){
 define("USER_EMAIL",$_SESSION["USER_EMAIL"]);
}
else{
 define("USER_EMAIL","");
}

//Setting default error and success status
$err = "n";
$errmsg = "";
$succ = "n";
$smsg = "";
?>