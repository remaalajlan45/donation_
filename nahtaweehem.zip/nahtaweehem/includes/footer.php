</div>
<!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->
<center>
    <div class="footerwrapper fixed-bottom">
        <div class="footertext">
            جميع الحقوق محفوظة - نحتويهم &copy; <?php echo date("Y"); ?>
        </div>

        <div>
            <!-- Add font awesome icons -->
            <a href="#" class="fa fa-facebook myfa"></a>
            <a href="#" class="fa fa-twitter myfa"></a>
            <a href="#" class="fa fa-youtube myfa"></a>
            <a href="#" class="fa fa-instagram myfa"></a>
            <a href="#" class="fa fa-snapchat-ghost myfa"></a>
        </div>
    </div>
</center>
<!-- jQuery 3 -->
<script src="plugin_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="plugin_components/bootstrap/dist/js/bootstrap.min.js"></script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('table').DataTable({
            "pageLength": 10,
            "paging": true,
            "ordering": true,
            "info": true,
            "language": {
                "decimal": "",
                "emptyTable": "لا يوجد بيانات متوفرة في الجدول",
                "info": "استعراض _START_ إلى _END_ من _TOTAL_ سجلات",
                "infoEmpty": "استعراض 0 إلى 0 من 0 السجلات",
                "infoFiltered": "(فلترة من  _MAX_  سجل)",
                "infoPostFix": "",
                "thousands": ",",
                "loadingRecords": "تحميل ...",
                "processing": "معالجة ...",
                "search": "بحث",
                "zeroRecords": "لا يوجد بيانات مطابقة للبحث",
                "paginate": {
                    "first": "السجل الأول",
                    "last": "السجل الأخير",
                    "next": "التالي",
                    "previous": "السابق"
                },
                "aria": {
                    "sortAscending": "ترتيب الأعمدة تصاعدياً",
                    "sortDescending": "ترتيب الأعمدة تنازلياً"
                },
                "lengthMenu": 'عرض <select>' +
                    '<option value="10">10</option>' +
                    '<option value="20">20</option>' +
                    '<option value="30">30</option>' +
                    '<option value="40">40</option>' +
                    '<option value="50">50</option>' +
                    '<option value="-1">-</option>' +
                    '</select> سجلات'
            }
        });
    });
</script>

<!-- https://flatpickr.js.org -->
<script src="https://npmcdn.com/flatpickr/dist/flatpickr.min.js"></script>
<script type="text/javascript">
    $("#a_date").flatpickr({
        enableTime: false,
        dateFormat: "Y-m-d",
        minDate: "today",
        "locale": {
            "firstDayOfWeek": 6 // set start day of week to Saturday
        }
    });
</script>
<script type="text/javascript">
    $("#dob").flatpickr({
        enableTime: false,
        dateFormat: "Y-m-d",
        maxDate: "today",
        "locale": {
            "firstDayOfWeek": 6 // set start day of week to Saturday
        }
    });
</script>

<!-- Stop Form Resubmission On Page Refresh -->
<script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>

<!-- Menu Toggle Script -->
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>

<script type="text/javascript">
    <?php
    if ($task == "update") {
    ?>
        $('#model_add_edit').modal('show');
        $("#btn_submit").html('تعديل');
        $("#model_add_edit_header").html('تعديل سجل');
    <?php
    } else {
    ?>
        $("#model_add_edit_header").html('إضافة سجل جديد');
    <?php
    }
    ?>
</script>

<a id="go_to_top_button"></a>
<script>
    var btn = $('#go_to_top_button');
    $(window).scroll(function() {
        if ($(window).scrollTop() > 300) {
            btn.addClass('show');
        } else {
            btn.removeClass('show');
        }
    });
    btn.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: 0
        }, '300');
    });
</script>

<?php
//Open model if set
if (isset($_REQUEST["support_type"]) && !isset($_POST["btn_submit"])) {
?>
    <script type="text/javascript">
        $('#model_support').modal('show');
    </script>
<?php
}
?>

</body>

</html>

<?php
//closing MySQLI connection
mysqli_close($link);
?>