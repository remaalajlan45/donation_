<body>
  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right border-left" id="sidebar-wrapper" <?php if (USER_EMAIL == "") echo "style=\"display:none\"" ?>>
      <div class="sidebar-heading">
        <?php
        if (USER_EMAIL != "") {
        ?>
          <center>
            <img class="img-responsive img-rounded" style="max-width: 100px;" src="img/logo.png">
            <h5><b><?php echo $u->name; ?></b></h5>
            <h6><?php echo user_type_lang($u->type); ?></h6>
          </center>
        <?php
        }
        ?>
      </div>
      <div iv class="list-group list-group-flush">
        <?php
        if (USER_EMAIL != "") {
          if ($u->type == "consultant") {
        ?>
            <a href="index.php" class="list-group-item list-group-item-action bg-light">البداية</a>
            <a href="manage_supports.php" class="list-group-item list-group-item-action bg-light">إدارة الاستشارات</a>
          <?php
          } else if ($u->type == "patient") {
          ?>
            <a href="index.php" class="list-group-item list-group-item-action bg-light">البداية</a>
            <a href="patient_manage_supports.php" class="list-group-item list-group-item-action bg-light">إدارة طلباتي</a>
          <?php
          } else if ($u->type == "supporter") {
          ?>
            <a href="index.php" class="list-group-item list-group-item-action bg-light">البداية</a>
            <a href="manage_supports.php" class="list-group-item list-group-item-action bg-light">إدارة طلبات الدعم</a>
        <?php
          }
        }
        ?>
        <a href="user_change_password.php" class="list-group-item list-group-item-action bg-light">تغيير كلمة المرور</a>
        <a href="user_edit_profile.php" class="list-group-item list-group-item-action bg-light">تعديل الملف الشخصي</a>
        <a href="user_logout.php" class="list-group-item list-group-item-action bg-light"> <span class="fa fa-sign-out"></span> تسجيل الخروج</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-primary bg-light">

        <?php
        if (USER_EMAIL != "") {
        ?>
          <button class="btn btn-outline-secondary" id="menu-toggle"><i class="fa fa-arrows-h" aria-hidden="true"></i></button>
        <?php
        }
        ?>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <i class="fa fa-navicon" style="color:#000; font-size:28px;"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 my-lg-0">
            <li class="nav-item mynav">
              <a class="nav-link btn btn-outline-info badge-pill" href="index.php">
                الرئيسية
              </a>
            </li>

            <?php
            if (USER_EMAIL == "") {
            ?>
              <li class="nav-item mynav">
                <a class="nav-link btn btn-warning badge-pill" href="register.php">
                  سجل معنا
                </a>
              </li>
              <li class="nav-item mynav">
                <a class="nav-link btn btn-outline-info badge-pill" href="login.php">
                  الدخول
                </a>
              </li>
              <li class="nav-item mynav">
                <a class="nav-link btn btn-outline-info badge-pill" href="donation.php">
                  تبرع
                </a>
              </li>
            <?php
            }
            ?>
            <li class="nav-item mynav">
              <a class="nav-link btn btn-outline-info badge-pill" href="about_us.php">
                من نحن
              </a>
            </li>

          </ul>

          <ul class="navbar-nav mr-auto my-2 align-items-end">
            <li class="nav-item">
              <div class="navbar-brand">
                <span class="navbar-logo">
                  <a href="index.php"><img src="img/logo.png" alt="logo" style="height: 3.0rem;"></a>
                </span>
              </div>
            </li>
          </ul>
        </div>
      </nav>

      <!--<h4 class="headingFont"> <?php echo SITENAME . " - " . $ptitle; ?> </h4>-->