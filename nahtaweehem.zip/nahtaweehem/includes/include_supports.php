<!-- Data Grid View part -->
<div>
    <?php
    //getting the list of data from the database
    if ($u->type == "patient") {
        $sql = "SELECT * FROM support WHERE patient_id='$p_id' ORDER BY id DESC";
    } else if ($u->type == "consultant") {
        $sql = "SELECT * FROM support WHERE type='consultation' ORDER BY id DESC";
    } else if ($u->type == "supporter") {
        $sql = "SELECT * FROM support WHERE type in ('education','donation') ORDER BY id DESC";
    }

    $res = mysqli_query($link, $sql);
    $numrows = mysqli_num_rows($res);
    if ($numrows > 0) {
        //if there is data, then display in table
    ?>
        <table id="myTable" class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>تاريخ الطلب</th>
                    <th>نوع الطلب</th>
                    <th>تفاصيل الطلب</th>
                    <?php
                    if ($u->type != "patient") {
                        echo "<th>الطفل مرسل الطلب</th>";
                    } else {
                        echo "<th>حذف</th>";
                    }
                    ?>
                    <th>الدعم المتوفر</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sn = 1;
                while ($obj = mysqli_fetch_object($res)) {
                ?>
                    <tr>
                        <td><?php echo $sn; ?></td>
                        <td><?php echo strip_tags($obj->datetime); ?></td>
                        <td><?php echo support_type_lang($obj->type); ?></td>
                        <td><?php echo strip_tags($obj->details); ?></td>

                        <?php
                        if ($u->type != "patient") {
                        ?>
                            <td>
                                <a data-toggle="modal" data-target="#model_patient<?php echo $obj->patient_id ?>" class="btn btn-outline-secondary">
                                    <?php echo user(patient($obj->patient_id)->user_id, "user_id")->name; ?>
                                </a>
                            </td>
                        <?php
                        } else {
                        ?>
                            <td>
                                <form method="post">
                                    <input type="hidden" name="did" value="<?php echo $obj->id; ?>">
                                    <button type="submit" onclick="return confirm('حذف هذا الطلب؟')" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></span></button>
                                </form>
                            </td>
                        <?php
                        }
                        ?>

                        <td>
                            <form method="post" action="support_replies.php">
                                <input type="hidden" name="support_id" value="<?php echo $obj->id; ?>">
                                <button type="submit" class="btn btn-success"><i class="fa fa-comment" aria-hidden="true"></i></span></button>
                            </form>
                        </td>
                    </tr>
                <?php
                    $sn++;
                    model_patient(patient($obj->patient_id));
                }
                ?>
            </tbody>
        </table>

    <?php
    } else {
        //if there is no data
        msg("لا يوجد بيانات ", "info");
    }
    ?>
</div>