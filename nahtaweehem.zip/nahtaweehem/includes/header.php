<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?php echo SITENAME . " - " . $ptitle; ?></title>

	<link href="https://fonts.googleapis.com/css?family=Almarai|Aref+Ruqaa|Changa&display=swap" rel="stylesheet">

	<!-- Bootstrap -->
	<link rel="stylesheet" href="plugin_components/bootstrap/dist/css/bootstrap.min.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="plugin_components/font-awesome/css/font-awesome.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="plugin_components/Ionicons/css/ionicons.min.css">
	<!-- datatables -->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">

	<!-- https://flatpickr.js.org -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

	<!-- website icon -->
	<link rel="shortcut icon" href="img/logo.png" type="image/png" />

	<!-- include the sytle file -->
	<link rel="stylesheet" type="text/css" href="includes/style.css">
	<link rel="stylesheet" type="text/css" href="includes/style_grid.css">
	<link rel="stylesheet" type="text/css" href="includes/style_simple_sidebar.css">
	<link rel="stylesheet" type="text/css" href="includes/style_btn_go_to_top.css">

</head>