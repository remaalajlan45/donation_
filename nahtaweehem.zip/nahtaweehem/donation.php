<?php
include("config.php");
include("functions.php");

//title of the page
$ptitle = "تبرع";

//including header files
include("includes/header.php");
include("includes/sidebar.php");
?>

<section class="mbr-fullscreen">
    <div class="bg3 mbr-overlay">
        <br><br><br><br><br><br><br>
        <div class="row text-center text-dark">
            <div class="col-lg-6">
                <h3><strong>التبرع المباشر</strong></h3>
                <br>
                <a class="btn btn-lg btn-primary badge-pill" href="register.php">تبرع هنا</a>
            </div>
            <div class="col-lg-6">
                <h3><strong>كن جزء من عائلتنا</strong></h3>
                <h4>اذا كنت معلم أو متبرع تفضل هنا</h4>
                <br>
                <a class="btn btn-lg btn-primary badge-pill" href="register.php">احتويهم</a>
            </div>
        </div>
    </div>
</section>

<?php
//including footer layout
include("includes/footer.php");
?>