<?php
@session_start();
//--- unset the session from browser ---
unset($_SESSION['USER_EMAIL']);
?>

<?php
include("config.php");
include("functions.php");

$ptitle = "تسجيل الخروج";
//--- include sub files ------
include("includes/header.php");
include("includes/sidebar.php");
?>
<div class="main">
    <?php
    msg("تم تسجيل الخروج بنجاح، شكراً لتواجدك معنا", "success");
    ?>
</div>

<?php
include("includes/footer.php");
?>