<?php
include("config.php");
include("functions.php");

//---- check user login and type
if (USER_EMAIL == "") {
    header("location:user_login.php");
    exit();
}

$user_obj = user(USER_EMAIL);
$id_user = $user_obj->id;
$type = $user_obj->type;

$email = $user_obj->email;
$old_email = $user_obj->email;
$name = $user_obj->name;
$phone = $user_obj->phone;
$dob = $user_obj->dob;
$address = $user_obj->address;

if ($type == "patient") {
    if ($patient_obj = patient($id_user, "user_id")) {
        $patient_id = $patient_obj->id;

        $iban = $patient_obj->iban;
        $hospital_id = $patient_obj->hospital_id;
        $cancer_type = $patient_obj->cancer_type;
        $bio = $patient_obj->bio;
        $needs = $patient_obj->needs;
    }
} else if ($type == "consultant") {
    if ($consultant_obj = consultant($id_user, "user_id")) {
        $consultant_id = $consultant_obj->id;

        $specialist = $consultant_obj->specialist;
    }
}

if (isset($_POST["btn_submit"])) {
    $name = trim($_POST["name"]);
    $email = strtolower(trim($_POST["email"]));
    $phone = trim($_POST["phone"]);
    $dob = trim($_POST["dob"]);
    $address = trim($_POST["address"]);

    if ($type == "patient") {
        $iban = trim($_POST["iban"]);
        $hospital_id = $_POST["hospital_id"];
        $cancer_type = trim($_POST["cancer_type"]);
        $bio = trim($_POST["bio"]);
        $needs = trim($_POST["needs"]);
    }

    //-- check if user exist or not -----
    if (user_exist($id_user, $email, $phone)) {
        $err = "y";
        $errmsg = "البريد الالكتروني او رقم الجوال مستخدمان مسبقاً، يجب كتابة بيانات جديدة";
    }

    //If there are no errors
    if ($err == "n") {
        try {
            $link->begin_transaction();

            $sql = "UPDATE user SET
				name = '$name',
                email = '$email',
                dob = '$dob',
                address = '$address',
                phone = '$phone'
				WHERE id=$id_user
				";

            $res = mysqli_query($link, $sql);
            echo mysqli_error($link);
            if ($res) {
                if ($type == "patient") {
                    $sql = "UPDATE patient SET
						cancer_type = '$cancer_type',
                        bio = '$bio',
                        needs = '$needs',
                        hospital_id = '$hospital_id',
                        iban = '$iban'
                        WHERE id=$patient_id
						";

                    $res = mysqli_query($link, $sql);
                    echo mysqli_error($link);

                    if ($res) {
                        if ($email != $old_email) {
                            $_SESSION['USER_EMAIL'] = $email;
                            header("location:index.php");
                        }
                        $succ = "y";
                        $smsg = "تم تعديل البيانات بنجاح";
                        //commit transaction
                        $link->commit();
                    } else {
                        $link->rollBack();
                        $err = "y";
                        $errmsg = "حدث خطأ ما";
                    }
                } else if ($type == "consultant") {
                    $sql = "UPDATE consultant SET
						specialist = '$specialist'
                        WHERE id=$consultant_id
						";

                    $res = mysqli_query($link, $sql);
                    echo mysqli_error($link);

                    if ($res) {
                        if ($email != $old_email) {
                            $_SESSION['USER_EMAIL'] = $email;
                            header("location:index.php");
                        }
                        $succ = "y";
                        $smsg = "تم تعديل البيانات بنجاح";
                        //commit transaction
                        $link->commit();
                    } else {
                        $link->rollBack();
                        $err = "y";
                        $errmsg = "حدث خطأ ما";
                    }
                } else {
                    if ($email != $old_email) {
                        $_SESSION['USER_EMAIL'] = $email;
                        header("location:index.php");
                    }
                    $succ = "y";
                    $smsg = "تم تعديل البيانات بنجاح";
                    //commit transaction
                    $link->commit();
                }
            } else {
                $link->rollBack();
            }
        } catch (PDOException $ex) {
            $link->rollBack();
            echo $ex->getMessage();
        }
    }
}


$ptitle = "تعديل الملف الشخصي";

//--- include sub files ------
include("includes/header.php");
include("includes/sidebar.php");
?>
<!-- =============================== End of Action Part =============================== -->

<!-- =============================== Design Part =============================== -->
<div class="main">
    <div>
        <?php
        //-- printing message if there is any message ---
        if ($err == "y") {
            msg($errmsg, "danger");
        }

        if ($succ == "y") {
            msg($smsg, "success");
        }
        ?>
    </div>

    <script type="text/javascript">
        function checkForm(form) {

            //Check Email
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if (!form.email.value.match(mailformat)) {
                alert("صيغة البريد الالكتروني غير صحيحة");
                form.email.focus();
                return false;
            }

            //Check phone of 10 digits
            var phone_format = /^\d{10}$/;
            if (!form.phone.value.match(phone_format)) {
                alert("رقم الجوال يجب ان يكون 10 ارقام");
                form.phone.focus();
                return false;
            }

            //If no errors then return true
            return true;
        }
    </script>
    <form name="myfrom" id="myfrom" enctype="multipart/form-data" method="post" onsubmit="return checkForm(this);">

        <div class="form-group">
            <label for="name">الاسم: <span class="mandatory">*</span></label>
            <input type="text" class="form-control" id="name" name="name" required maxlength="100" placeholder="ادخل اسمك كاملاً" value="<?php echo $name; ?>">
        </div>

        <div class="form-group">
            <label>البريد الالكتروني:<span class="mandatory">*</span></label>
            <input type="text" class="form-control" id="email" name="email" required maxlength="100" placeholder="ادخل بريدك الالكتروني" value="<?php echo $email; ?>">
        </div>

        <div class="form-group">
            <label>الجوال:<span class="mandatory">*</span></label>
            <input type="tel" class="form-control" id="phone" name="phone" required maxlength="10" placeholder="ادخل رقم الجوال المكون من 10 ارقام" value="<?php echo $phone; ?>">
        </div>

        <div class="form-group">
            <label for="dob">تاريخ الميلاد:<span class="mandatory">*</span></label>
            <input id="dob" name="dob" class="form-control" required placeholder="ادخل تاريج الميلاد" data-input value="<?php echo $dob; ?>" />
        </div>

        <div class="form-group">
            <label for="address">العنوان: <span class="mandatory">*</span></label>
            <input type="text" class="form-control" id="address" name="address" maxlength="100" required placeholder="ادخل عنوانك كاملاً" maxlength="100" value="<?php echo $address; ?>">
        </div>


        <?php
        if ($u->type == "patient") {
        ?>
            <div class="form-group">
                <label>رقم حساب بنكي للدعم المادي:<span class="mandatory">*</span></label>
                <input type="text" class="form-control" id="iban" name="iban" required placeholder="مثال SA03800012364587XXX7XXXX" minlength="20" maxlength="100" value="<?php echo $iban; ?>">
            </div>

            <div class="form-group">
                <label>المستشفى:<span class="mandatory">*</span></label>
                <?php hospital_list($hospital_id); ?>
            </div>

            <div class="form-group">
                <label>نوع المرض:</label>
                <input type="text" class="form-control" id="cancer_type" name="cancer_type" placeholder="ادخل نوع المرض" maxlength="100" value="<?php echo $cancer_type; ?>">
            </div>

            <div class="form-group">
                <label>معلومات اضافية عنك:</label>
                <textarea id="bio" name="bio" class="form-control" rows="2" placeholder="اكتب نبذه تعريفية عنك"><?php echo $bio; ?></textarea>
            </div>

            <div class="form-group">
                <label>احتياجاتك:</label>
                <textarea name="needs" id="needs" class="form-control" rows="2" placeholder="اكتب احتياجاتك هنا"><?php echo $needs; ?></textarea>
            </div>
        <?php
        } else if ($u->type == "consultant") {
        ?>
            <div class="form-group">
                <label>التخصص:</label>
                <input type="text" class="form-control" id="specialist" name="specialist" placeholder="ادخل تخصصك" maxlength="100" value="<?php echo $specialist; ?>">
            </div>
        <?php
        }
        ?>

        <button id="btn_submit" name="btn_submit" type="submit" class="btn btn-primary">تعديل البيانات</button>
    </form>
    <div>

        <?php
        include("includes/footer.php");
        ?>