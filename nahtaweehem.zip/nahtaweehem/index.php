<?php
include("config.php");
include("functions.php");

//title of the page
$ptitle = "الصفحة الرئيسية";

//including header files
include("includes/header.php");
include("includes/sidebar.php");
?>

<?php
if (USER_EMAIL == "") {
?>
    <section class="mbr-fullscreen">
        <div class="bg1 mbr-overlay">
            <div style="color:white; position: absolute;  top: 65%;  left: 30%;  transform: translate(-50%, -50%);">
                <span style="font-size:40pt;"><strong>هل تريد المساعدة؟</strong></span>
                <p style="font-size:20pt;">
                    نحن ممتنون إلى الأبد لأولئك منكم الذين يرغبون
                    <br>
                    في فتح أبوابهم لهذه العائلات والأطفال المستحقين
                    <br>
                    ! شارك معنا أو كن متبرعًا وامنح كل طفل فرصة قتال
                </p>
                <a class="btn btn-warning badge-pill btn-lg" style="padding-right:20px; padding-left:20px;" href="donation.php">تبرع الآن <i class="fa fa-heart-o" aria-hidden="true"></i></a>
            </div>
    </section>

    <section class="mbr-fullscreen">
        <div class="bg2 mbr-overlay">
            <div class="text-center" style="color:black; padding-top:4%;">
                <span style="font-size:40pt;"><strong>!امنحهم الأمل</strong></span>
                <h4 style="font-size:20pt;">
                    "قُم لِلمُعَلِّمِ وَفِّهِ التَبجيلا كادَ المُعَلِّمُ أَن يَكونَ رَسولا"
                    <br>
                    أيها المعلم الفاضل تستطيع تقديم دروس وشروحات لهؤلاء الصغار ليكملوا مسيرة تعليمهم.
                </h4>
                <br>
                <a class="btn btn-warning btn-lg badge-pill shadow-lg" style="padding-right:20px; padding-left:20px;" href="register.php">تفضل هنا أستاذي</a>
            </div>
        </div>
    </section>
    <?php
} else {
    if ($u->type == "consultant") {
    ?>
        <div class="main bg">
            <h3 class="text-center" style="font-size:25pt;">إحصائيات النظام</h3>
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-info">
                        <div class="card-header h5">طلبات الدعم التعليمي</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-book fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("support", "WHERE type='education'"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-success">
                        <div class="card-header h5">طلبات الدعم المادي</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-money fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("support", "WHERE type='donation'"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-primary">
                        <div class="card-header h5">طلبات الدعم الاستشاري</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-comments fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("support", "WHERE type='consultation'"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-secondary">
                        <div class="card-header h5">حسابات الاستشاريين</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-user fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("user", "WHERE type='consultant'"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-white">
                        <div class="card-header h5 text-dark">حسابات الاطفال</div>
                        <div class="card-body">
                            <span class="pull-right text-dark"><i class="fa fa-user fa-3x"></i></span>
                            <span class="pull-left">
                                <h2 class="text-dark"><?php echo numrows("user", "WHERE type='patient'"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-danger">
                        <div class="card-header h5">حسابات الداعمين</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-user fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("user", "WHERE type='supporter'"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
    } elseif ($u->type == "patient") {
    ?>
        <div class="main bg">
            <h3 class="text-center" style="font-size:25pt;"> مرحباً بك يا عزيزي</h3>
            <h3 class="text-center" style="font-size:16pt;"> بإمكانك متابعة طلبات الدعم التي قمت بارسالها الى المختصين واستعراض الرد عليها</h3>
            <br>
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-info">
                        <div class="card-header h5">الدعم التعليمي</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-book fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("support", "WHERE type='education' AND patient_id=$p_id"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                        <div class="card-footer bg-white">
                            <form method="post" action="patient_manage_supports.php">
                                <input type="hidden" name="support_type" value="education">
                                <button type="submit" class="btn btn-block btn-outline-info"> طلب دعم تعليمي </button>
                            </form>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-success">
                        <div class="card-header h5">الدعم المادي</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-money fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("support", "WHERE type='donation' AND patient_id=$p_id"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                        <div class="card-footer bg-white">
                            <form method="post" action="patient_manage_supports.php">
                                <input type="hidden" name="support_type" value="education">
                                <button type="submit" class="btn btn-block btn-outline-success"> طلب دعم مادي </button>
                            </form>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="card text-white bg-primary">
                        <div class="card-header h5">الدعم الاستشاري</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-comments fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("support", "WHERE type='consultation' AND patient_id=$p_id"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                        <div class="card-footer bg-white">
                            <form method="post" action="patient_manage_supports.php">
                                <input type="hidden" name="support_type" value="education">
                                <button type="submit" class="btn btn-block btn-outline-primary"> طلب دعم استشاري </button>
                            </form>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
    } elseif ($u->type == "supporter") {
    ?>
        <div class="main bg">

            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="card text-white bg-info">
                        <div class="card-header h5">طلبات الدعم التعليمي</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-book fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("support", "WHERE type='education'"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="card text-white bg-success">
                        <div class="card-header h5">طلبات الدعم المادي</div>
                        <div class="card-body">
                            <span class="pull-right"><i class="fa fa-money fa-3x"></i></span>
                            <span class="pull-left">
                                <h2><?php echo numrows("support", "WHERE type='donation'"); ?></h2>
                            </span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
    }
}
    ?>

    <?php
    //including footer layout
    include("includes/footer.php");
    ?>