<?php
include("config.php");
include("functions.php");

//---- check user login and type
if (USER_EMAIL == "") {
    header("location:user_login.php");
    exit();
}

//get support_id sent from previous page
if (isset($_REQUEST["support_id"])) {
    $support_id = $_REQUEST["support_id"];
    if (support($support_id) == false) {
        header("location:index.php");
        exit();
    } else {
        $obj_support = support($support_id);
    }
} else {
    header("location:index.php");
    exit();
}


if (isset($_POST["btn_submit_consultation"])) {
    $replay = trim($_POST["replay"]);
    $replay = mysqli_real_escape_string($link, $replay);

    //writing data to database
    $sql = "INSERT INTO support_consultation SET replay = '$replay', support_id = '$support_id',	consultant_id = '$c_id'";

    $res = mysqli_query($link, $sql);
    echo mysqli_error($link);
    if ($res) {
        $succ = "y";
        $smsg = "شكراً لك تم الرد على الاستشارة بنجاح";
    } else {
        $err = "y";
        $errmsg = "حدث خطأ ما";
    }
}

if (isset($_POST["btn_submit_education"])) {
    $url = trim($_POST["url"]);
    $url = mysqli_real_escape_string($link, $url);

    //writing data to database
    $sql = "INSERT INTO support_education SET url = '$url', support_id = '$support_id',	supporter_id = '$s_id'";

    $res = mysqli_query($link, $sql);
    echo mysqli_error($link);
    if ($res) {
        $succ = "y";
        $smsg = "شكراً لك تم الرد على الطلب التعليمي بنجاح";
    } else {
        $err = "y";
        $errmsg = "حدث خطأ ما";
    }
}

if (isset($_POST["btn_submit_donation"])) {
    $image = upload_file("img/uploads/", $_FILES['image'], "image", $err, $errmsg);
    if ($err == "n") {
        //writing data to database
        $sql = "INSERT INTO support_donation SET image = '$image', support_id = '$support_id',	supporter_id = '$s_id'";

        $res = mysqli_query($link, $sql);
        echo mysqli_error($link);
        if ($res) {
            $succ = "y";
            $smsg = "شكراً لك تم الرد على طلب التبرع ،، بارك الله فيك";
        } else {
            $err = "y";
            $errmsg = "حدث خطأ ما";
        }
    }
}


//-- If Task is Delete ---
if (isset($_POST["did"])) {
    $id = $_POST["did"];

    $did_type = $_POST["did_type"];

    if ($did_type == "consultation") {
        $sql = "DELETE FROM support_consultation WHERE id = '$id'";
    } else if ($did_type == "donation") {
        $sql = "DELETE FROM support_donation WHERE id = '$id'";
    } else if ($did_type == "education") {
        $sql = "DELETE FROM support_education WHERE id = '$id'";
    }

    $res = mysqli_query($link, $sql);
    if ($res) {
        $succ = "y";
        $smsg = "تم الحذف بنجاح";
    } else {
        $err = "y";
        $errmsg = "حدث خطأ ما";
    }
}

$ptitle = "الدعم المتوفر";
//--- include sub files ------
include("includes/header.php");
include("includes/sidebar.php");
?>

<!-- =============================== End of Action Part =============================== -->
<!-- =============================== Design Part =============================== -->
<div class="main">
    <div>
        <?php
        //-- printing message if there is any message ---
        if ($err == "y") {
            msg($errmsg, "danger");
        }

        if ($succ == "y") {
            msg($smsg, "success");
        }
        ?>
    </div>

    <style tyle="text/css">
        .form-group {
            width: 100%;
        }
    </style>

    <section class="card bg-white">
        <div class="card-header text-center text-secondary">
            <h5>الدعم المتوفر على الطلب المرسل</h5>
        </div>
        <div class="card-body">
            <?php
            if (USER_EMAIL != "" && $u->type != "patient") {
                if ($obj_support->type == "consultation" && $u->type == "consultant") {
            ?>
                    <div class="card">
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="support_id" value="<?php echo $support_id; ?>">
                                <div class="form-group">
                                    <textarea class="form-control" name="replay" id="replay" class="form-control" required="required" placeholder="اكتب ردك المناسب على الاستشارة في هذا المكان"></textarea>
                                </div>
                                <button id="btn_submit_consultation" name="btn_submit_consultation" type="submit" class="btn btn-primary">الرد على الاستشارة</button>
                            </form>
                        </div>
                    </div>
                    <br>
                <?php
                } else if ($obj_support->type == "education" && $u->type == "supporter") {
                ?>
                    <div class="card">
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="support_id" value="<?php echo $support_id; ?>">
                                <div class="form-group">
                                    <label for="url">رابط الدرس على يوتيوب: </label>
                                    <textarea name="url" id="url" class="form-control" rows="10" maxlength="1000" placeholder="قم بتضمين فيديو من اليوتيوب على شكل iframe"></textarea>
                                </div>
                                <button id="btn_submit_education" name="btn_submit_education" type="submit" class="btn btn-primary">إرسال الدرس</button>
                            </form>
                        </div>
                    </div>
                    <br>
                <?php
                } else if ($obj_support->type == "donation" && $u->type == "supporter") {
                ?>
                    <div class="card">
                        <div class="card-body">
                            <p class="text-center">
                                قم بإجراء تبرع الكتروني بمبلغ معين على حساب عائلة الطفل رقم
                                (<?php echo patient($obj_support->patient_id)->iban; ?>)
                                <br>
                                وبعد ذلك قم بارفاق إيصال الدفع هنا.
                            </p>
                            <form method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="support_id" value="<?php echo $support_id; ?>">
                                <div class="form-group">
                                    <label for="image">سند التبرع: <span class="mandatory">*</span></label>
                                    <input type="file" accept="image/*" name="image" id="image" class="form-control" required>
                                </div>
                                <button id="btn_submit_donation" name="btn_submit_donation" type="submit" class="btn btn-primary">إرسال سند التبرع</button>
                            </form>
                        </div>
                    </div>
                    <br>
                <?php
                }
            }

            if ($obj_support->type == "consultation") {
                $sql = "SELECT * FROM support_consultation WHERE support_id = '$support_id'";
            } else if ($obj_support->type == "donation") {
                $sql = "SELECT * FROM support_donation WHERE support_id = '$support_id'";
            } else if ($obj_support->type == "education") {
                $sql = "SELECT * FROM support_education WHERE support_id = '$support_id'";
            }

            $res = mysqli_query($link, $sql);
            $numrows = mysqli_num_rows($res);
            if ($numrows > 0) {
                while ($obj = mysqli_fetch_object($res)) {

                    if ($obj_support->type == "consultation") {
                        $obj_replay_user = user(consultant($obj->consultant_id)->user_id);
                    } else if ($obj_support->type == "donation") {
                        $obj_replay_user = user(supporter($obj->supporter_id)->user_id);
                    } else if ($obj_support->type == "education") {
                        $obj_replay_user = user(supporter($obj->supporter_id)->user_id);
                    }

                ?>
                    <article>
                        <div class="card card-default">
                            <div class="card-body">
                                <header>
                                    <div>
                                        <i class="fa fa-user"></i> <?php echo $obj_replay_user->name; ?>
                                    </div>
                                    <div>
                                        <i class="fa fa-clock-o"></i> <?php echo $obj->datetime; ?>
                                    </div>
                                </header>
                                <div>
                                    <?php
                                    if ($obj_support->type == "consultation") {
                                    ?>
                                        <p style="color:blue; font-size:110%; font-style:italic;">
                                            <?php echo $obj->replay; ?>
                                        </p>
                                    <?php
                                    } else if ($obj_support->type == "donation") {
                                    ?>
                                        <center>
                                            <a target="_blank" href="<?php echo $obj->image; ?>"><img src="<?php echo $obj->image; ?>" class="img-thumbnail myimg">
                                            </a>
                                        </center>
                                    <?php
                                    } else if ($obj_support->type == "education") {
                                    ?>
                                        <center><?php echo $obj->url; ?></center>
                                    <?php
                                    }
                                    ?>


                                    <?php
                                    //Show delete button to replay owner
                                    if (USER_EMAIL != "") {
                                        if ($user_id == $obj_replay_user->id) {
                                    ?>
                                            <form method="post" style="float: left;">
                                                <input type="hidden" name="support_id" value="<?php echo $support_id; ?>">
                                                <input type="hidden" name="did" value="<?php echo $obj->id; ?>">
                                                <input type="hidden" name="did_type" value="<?php echo $obj_support->type; ?>">
                                                <button type="submit" onclick="return confirm('حذف هذا الرد؟')" class="btn btn-danger"><span class="fa fa-trash"></span></button>
                                            </form>
                                    <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>

                    </article>
                    <br>
            <?php
                }
            } else {
                msg("لا يوجد ردود حالياً", "info");
            }
            ?>
        </div>
    </section>


</div>


<?php
include("includes/footer.php");
?>