<?php
include("config.php");
include("functions.php");

//title of the page
$ptitle = "تسجيل دخول";

//including header files
include("includes/header.php");
include("includes/sidebar.php");
?>

<section class="mbr-fullscreen">
    <div class="bg6 mbr-overlay">
        <br><br><br><br><br><br><br>
        <div class="row text-center text-white">
            <div class="col-lg-4">
                <h2><strong>مرحبا بك ياصغيري</strong></h2>
                <br><br><br><br>
                <a class="btn btn-lg btn-light badge-pill" href="user_login.php">تسجيل دخول الطفل</a>
            </div>
            <div class="col-lg-4">
                <h2><strong>مرحبا بك معنا</strong></h2>
                <br><br><br><br>
                <a class="btn btn-lg btn-light badge-pill" href="user_login.php">تسجيل دخول داعم</a>
            </div>
            <div class="col-lg-4">
                <h2><strong>مرحبا بك</strong></h2>
                <br><br><br><br>
                <a class="btn btn-lg btn-light badge-pill" href="user_login.php">تسجيل دخول استشاري</a>
            </div>
        </div>
    </div>
    </div>
</section>

<?php
//including footer layout
include("includes/footer.php");
?>