<?php
include("config.php");
include("functions.php");

//---- check user login and type
if (USER_EMAIL == "" || $u->type != "patient") {
    header("location:user_login.php");
    exit();
}

if (isset($_REQUEST["support_type"])) {
    $support_type = $_REQUEST["support_type"];
} else {
    $support_type = "";
}

/* =============================== Action Part =============================== */
//-- If Task is Delete ---
if (isset($_POST["did"])) {
    $did = $_POST["did"];

    //-- writing query to delete from the table
    $sql = "DELETE FROM support WHERE id = '$did'";
    $res = mysqli_query($link, $sql);
    if ($res) {
        $succ = "y";
        $smsg = "تم حذف طلب الدعم بنجاح";
    } else {
        $err = "y";
        $errmsg = "حدث خطأ ما";
    }
}

//----- Getting submitted data of the form --------
if (isset($_POST["btn_submit"])) {

    $support_type = $_POST["support_type"];
    $details = trim($_POST["details"]);

    //writing data to database
    $sql = "INSERT INTO support SET
		type = '$support_type',
		details = '$details',
		patient_id = '$p->id'
		";

    $res = mysqli_query($link, $sql);
    echo mysqli_error($link);

    if ($res) {
        //assigning success
        $succ = "y";
        $smsg = "تم إرسال طلب الدعم الى المختصين، في حال تلقيت اي رد سيتم اظهاره هنا في طلباتك";
    } else {
        $err = "y";
        $errmsg = "حدث خطأ ما";
    }
}

$ptitle = "إدارة طلباتي";
//--- include sub files ------
include("includes/header.php");
include("includes/sidebar.php");
?>

<!-- =============================== End of Action Part =============================== -->
<!-- =============================== Design Part =============================== -->
<div class="main">
    <div>
        <?php
        //-- printing message if there is any message ---
        if ($err == "y") {
            msg($errmsg, "danger");
        }

        if ($succ == "y") {
            msg($smsg, "success");
        }
        ?>
    </div>

    <style type="text/css">
        .form-group {
            width: 100%;
        }
    </style>

    <!-- Trigger the modal with a button -->
    <button id="btn_model_support" type="button" class="btn btn-primary" data-toggle="modal" data-target="#model_support">إظافة طلب دعم</button>


    <!-- Modal -->
    <div id="model_support" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="model_support_header"></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <br>
                </div>
                <div class="modal-body">
                    <form method="post" enctype="multipart/form-data">

                        <div class="form-group">
                            <label>نوع الطلب: <span class="mandatory">*</span></label>
                            <?php support_type_list($support_type); ?>
                        </div>

                        <div class="form-group">
                            <label>تفاصيل الطلب:</label>
                            <textarea name="details" id="details" class="form-control" rows="5" placeholder="اكتب تفاصيل طلبك هنا بشكل واضح"></textarea>
                        </div>

                        <br>

                        <button id="btn_submit" name="btn_submit" type="submit" class="btn btn-primary">إرسال الطلب</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <br><br>

    <?php
    include("includes/include_supports.php");
    ?>

</div>


<?php
include("includes/footer.php");
?>