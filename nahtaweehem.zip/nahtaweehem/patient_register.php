<?php
include("config.php");
include("functions.php");

//---- check if already logged in
if (USER_EMAIL != "") {
    header("location:index.php");
    exit();
}

if (isset($_POST["btn_submit"])) {
    //grabbing the form data here
    $type = "patient";

    $name = trim($_POST["name"]);
    $email = strtolower(trim($_POST["email"]));
    $password = $_POST["password"];
    $phone = trim($_POST["phone"]);
    $dob = trim($_POST["dob"]);
    $address = trim($_POST["address"]);

    $iban = trim($_POST["iban"]);
    $hospital_id = $_POST["hospital_id"];
    $cancer_type = trim($_POST["cancer_type"]);
    $bio = trim($_POST["bio"]);
    $needs = trim($_POST["needs"]);

    //-- check if user exist or not -----
    if (user_exist("0", $email, $phone)) {
        $err = "y";
        $errmsg = "البريد الالكتروني او رقم الجوال مستخدمان مسبقاً، يجب كتابة بيانات جديدة";
    }

    //if no errors occured during validation
    if ($err == "n") {
        //preventing mysql injection here ''
        $name = mysqli_real_escape_string($link, $name);
        $password = mysqli_real_escape_string($link, $password);
        $address = mysqli_real_escape_string($link, $address);
        $cancer_type = mysqli_real_escape_string($link, $cancer_type);
        $bio = mysqli_real_escape_string($link, $bio);
        $needs = mysqli_real_escape_string($link, $needs);

        try {
            $link->begin_transaction();

            //writing data to database
            $sql = "INSERT INTO user SET
			type = '$type',
			name = '$name',
			email = '$email',
			password = '$password',
			dob = '$dob',
			address = '$address',
			phone = '$phone'
			";

            $res = mysqli_query($link, $sql);
            echo mysqli_error($link);

            if ($res) {

                $last_id = $link->insert_id;

                $sql = "INSERT INTO patient SET
					cancer_type = '$cancer_type',
					bio = '$bio',
					needs = '$needs',
					hospital_id = '$hospital_id',
					iban = '$iban',
					user_id = '$last_id'
					";

                $res = mysqli_query($link, $sql);
                echo mysqli_error($link);

                if ($res) {
                    //commit transaction
                    $link->commit();
                    $succ = "y";
                    $smsg = "تم إنشاء الحساب بنجاح، يمكنك الان تسجيل الدخول";
                } else {
                    $link->rollBack();
                    $err = "y";
                    $errmsg = "حدث خطأ ما";
                }
            } else {
                $link->rollBack();
                $err = "y";
                $errmsg = "حدث خطأ ما";
            }
        } catch (PDOException $ex) {
            $link->rollBack();
            echo $ex->getMessage();
        }
    }
}

$ptitle = "إنشاء حساب طفل";

//--- include sub files ------
include("includes/header.php");
include("includes/sidebar.php");
?>
<!-- =============================== End of Action Part =============================== -->

<!-- =============================== Design Part =============================== -->
<div class="main">
    <div>
        <?php
        //-- printing message if there is any message ---
        if ($err == "y") {
            msg($errmsg, "danger");
        }

        if ($succ == "y") {
            msg($smsg, "success");
        }
        ?>
    </div>

    <script type="text/javascript">
        function checkForm(form) {

            //Check Email
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if (!form.email.value.match(mailformat)) {
                alert("صيغة البريد الالكتروني غير صحيحة");
                form.email.focus();
                return false;
            }

            if (form.password.value.length < 8) {
                alert("كلمة المرور يجب الا تقل عن 8 احرف");
                form.password.focus();
                return false;
            }

            //Check phone of 10 digits
            var phone_format = /^\d{10}$/;
            if (!form.phone.value.match(phone_format)) {
                alert("رقم الجوال يجب ان يكون 10 ارقام");
                form.phone.focus();
                return false;
            }

            //If no errors then return true
            return true;
        }
    </script>
    <form name="myfrom" id="myfrom" enctype="multipart/form-data" method="post" onsubmit="return checkForm(this);">

        <div class="form-group">
            <label for="name">الاسم: <span class="mandatory">*</span></label>
            <input type="text" class="form-control" id="name" name="name" required placeholder="ادخل اسمك كاملاً" maxlength="100">
        </div>

        <div class="form-group">
            <label>البريد الالكتروني:<span class="mandatory">*</span></label>
            <input type="text" class="form-control" id="email" name="email" required placeholder="ادخل بريدك الالكتروني" maxlength="100">
        </div>

        <div class="form-group">
            <label>كلمة المرور:<span class="mandatory">*</span></label>
            <input type="password" class="form-control" id="password" name="password" required placeholder="ادخل كلمة المرور بحيث لا تقل عن 8 احرف" ;>
        </div>

        <div class="form-group">
            <label>الجوال:<span class="mandatory">*</span></label>
            <input type="tel" class="form-control" id="phone" name="phone" required placeholder="ادخل رقم الجوال المكون من 10 ارقام" maxlength="10">
        </div>

        <div class="form-group">
            <label for="dob">تاريخ الميلاد:<span class="mandatory">*</span></label>
            <input id="dob" name="dob" class="form-control" required placeholder="ادخل تاريج الميلاد" data-input />
        </div>

        <div class="form-group">
            <label for="address">العنوان: <span class="mandatory">*</span></label>
            <input type="text" class="form-control" id="address" name="address" required placeholder="ادخل عنوانك كاملاً" maxlength="100">
        </div>


        <div class="form-group">
            <label>رقم حساب بنكي للدعم المادي:<span class="mandatory">*</span></label>
            <input type="text" class="form-control" id="iban" name="iban" required placeholder="مثال SA03800012364587XXX7XXXX" minlength="20" maxlength="100">
        </div>


        <div class="form-group">
            <label>المستشفى:<span class="mandatory">*</span></label>
            <?php hospital_list(""); ?>
        </div>

        <div class="form-group">
            <label>نوع المرض:</label>
            <input type="text" class="form-control" id="cancer_type" name="cancer_type" placeholder="ادخل نوع المرض" maxlength="100">
        </div>

        <div class="form-group">
            <label>معلومات اضافية عنك:</label>
            <textarea id="bio" name="bio" class="form-control" rows="2" placeholder="اكتب نبذه تعريفية عنك"></textarea>
        </div>

        <div class="form-group">
            <label>احتياجاتك:</label>
            <textarea name="needs" id="needs" class="form-control" rows="2" placeholder="اكتب احتياجاتك هنا"></textarea>
        </div>


        <button id="btn_submit" name="btn_submit" type="submit" class="btn btn-primary">إنشاء حساب</button>
        <button type="reset" class="btn btn-outline-secondary">تصفية الحقول</button>
    </form>

    <br><br>
    <a href="user_login.php">لديك حساب مسبقاً، سجل دخولك هنا</a>

</div>
<br><br><br>

<?php
include("includes/footer.php");
?>