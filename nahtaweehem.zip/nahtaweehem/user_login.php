<?php
include("config.php");
include("functions.php");

$ptitle = "تسجيل الدخول";

//----- Getting submitted data of the form --------
if (isset($_POST["email"]) && isset($_POST["password"])) {
	$email = strtolower($_POST["email"]);
	$password = $_POST["password"];

	//-- retrieving data from database with submitted email and password ---
	$sql = "SELECT * FROM user WHERE email = '$email' && password = '$password'";
	$res = mysqli_query($link, $sql);
	$numrows = mysqli_num_rows($res);

	//--- if there is user with submitted email and password ---
	if ($numrows > 0) {
		//-- save Session to browser if  password and email get matched.
		$_SESSION['USER_EMAIL'] = $email;
		header("location:index.php");
		exit();
	} else {
		//--- if there is no data with submitted email and password ---
		$err = "y";
		$errmsg = "تأكد من بريدك الالكتروني و/أو كلمة المرور";
	}
}

//--- include sub files ------
include("includes/header.php");
include("includes/sidebar.php");
?>
<div class="main">
	<div>
		<?php
		//-- printing message if there is any message ---
		if ($err == "y") {
			msg($errmsg, "danger");
		}

		if ($succ == "y") {
			msg($smsg, "success");
		}
		?>
	</div>

	<form method="post">
		<div class="form-group">
			<label for="email">البريد الالكتروني:<span class="mandatory">*</span></label>
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text"><i class="fa fa-envelope"></i></span>
				</div>
				<input type="email" class="form-control" id="email" name="email" required placeholder="ادخل بريدك الالكتروني">
			</div>
		</div>

		<div class="form-group">
			<label for="password">كلمة المرور:<span class="mandatory">*</span></label>
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text"><i class="fa fa-key"></i></span>
				</div>
				<input type="password" class="form-control" id="password" name="password" required placeholder="ادخل كلمة المرور">
			</div>
		</div>

		<button type="submit" class="btn btn-primary">تسجيل الدخول</button>
		<button type="reset" class="btn btn-outline-secondary">تصفية الحقول</button>
	</form>
</div>
<?php
include("includes/footer.php");
?>